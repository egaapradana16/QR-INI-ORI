/**
 * Advanced QR Code Generator Utility
 * Support for: Logos, Gradients, and Custom High-Res Export
 */

const generateQRCode = async (config) => {
    try {
        const { 
            value, 
            fgColor, 
            bgColor, 
            margin, 
            width, 
            logo, 
            logoPadding, 
            logoSize: logoSizeRatio,
            useGradient,
            gradientColor,
            gradientType
        } = config;
        
        // Generate base QR canvas using qrcode library
        const canvas = document.createElement('canvas');
        await QRCode.toCanvas(canvas, value, {
            width: width,
            margin: margin,
            color: {
                dark: fgColor,
                light: bgColor
            },
            errorCorrectionLevel: logo ? 'H' : 'M'
        });

        const ctx = canvas.getContext('2d');

        // Apply Gradient if enabled
        if (useGradient) {
            ctx.globalCompositeOperation = 'source-in';
            let gradient;
            if (gradientType === 'linear') {
                gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            } else {
                gradient = ctx.createRadialGradient(
                    canvas.width / 2, canvas.height / 2, 0,
                    canvas.width / 2, canvas.height / 2, canvas.width / 2
                );
            }
            gradient.addColorStop(0, fgColor);
            gradient.addColorStop(1, gradientColor);
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.globalCompositeOperation = 'source-over';
        }

        // Add logo if present
        if (logo) {
            const logoImage = new Image();
            
            return new Promise((resolve, reject) => {
                logoImage.onload = () => {
                    const finalLogoSize = canvas.width * logoSizeRatio;
                    const x = (canvas.width - finalLogoSize) / 2;
                    const y = (canvas.height - finalLogoSize) / 2;
                    
                    // Draw white (background color) box for logo
                    ctx.fillStyle = bgColor;
                    
                    // Logo container with padding
                    const pad = logoPadding;
                    // Drawing a rounded background for logo
                    const rectX = x - pad;
                    const rectY = y - pad;
                    const rectW = finalLogoSize + pad * 2;
                    const rectH = finalLogoSize + pad * 2;
                    const radius = pad > 0 ? pad : 5;

                    ctx.beginPath();
                    ctx.moveTo(rectX + radius, rectY);
                    ctx.lineTo(rectX + rectW - radius, rectY);
                    ctx.quadraticCurveTo(rectX + rectW, rectY, rectX + rectW, rectY + radius);
                    ctx.lineTo(rectX + rectW, rectY + rectH - radius);
                    ctx.quadraticCurveTo(rectX + rectW, rectY + rectH, rectX + rectW - radius, rectY + rectH);
                    ctx.lineTo(rectX + radius, rectY + rectH);
                    ctx.quadraticCurveTo(rectX, rectY + rectH, rectX, rectY + rectH - radius);
                    ctx.lineTo(rectX, rectY + radius);
                    ctx.quadraticCurveTo(rectX, rectY, rectX + radius, rectY);
                    ctx.closePath();
                    ctx.fill();
                    
                    // Draw logo
                    ctx.drawImage(logoImage, x, y, finalLogoSize, finalLogoSize);
                    resolve(canvas.toDataURL('image/png'));
                };
                logoImage.onerror = () => reject(new Error('Failed to load logo image'));
                logoImage.src = logo;
            });
        }

        return canvas.toDataURL('image/png');
    } catch (err) {
        console.error('QR Generation failed:', err);
        throw err;
    }
};

const downloadImage = (dataUrl, filename = 'qrcode.png') => {
    try {
        const link = document.createElement('a');
        link.href = dataUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } catch (e) {
        console.error('Download failed', e);
    }
};

const copyToClipboard = async (text) => {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (err) {
        console.error('Failed to copy: ', err);
        return false;
    }
};